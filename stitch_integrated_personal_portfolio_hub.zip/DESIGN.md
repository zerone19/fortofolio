---
name: Kinetic Blueprint Light
colors:
  surface: '#f5fafe'
  surface-dim: '#d5dbdf'
  surface-bright: '#f5fafe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4f9'
  surface-container: '#e9eff3'
  surface-container-high: '#e3e9ed'
  surface-container-highest: '#dee3e7'
  on-surface: '#161c20'
  on-surface-variant: '#3d484f'
  inverse-surface: '#2b3135'
  inverse-on-surface: '#ecf1f6'
  outline: '#6d7980'
  outline-variant: '#bcc8d0'
  surface-tint: '#006684'
  primary: '#006684'
  on-primary: '#ffffff'
  primary-container: '#2ac7fb'
  on-primary-container: '#005067'
  inverse-primary: '#68d3ff'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2e2e2'
  on-secondary-container: '#646464'
  tertiary: '#865300'
  on-tertiary: '#ffffff'
  tertiary-container: '#fba72f'
  on-tertiary-container: '#694000'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bee9ff'
  primary-fixed-dim: '#68d3ff'
  on-primary-fixed: '#001f2a'
  on-primary-fixed-variant: '#004d64'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c6'
  on-secondary-fixed: '#1b1b1b'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb960'
  on-tertiary-fixed: '#2b1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f5fafe'
  on-background: '#161c20'
  surface-variant: '#dee3e7'
  surface-main: '#FFFFFF'
  accent-yellow: '#ffde59'
  blueprint-cyan: '#2ac7fb'
  deep-tech-black: '#0e0e0e'
  neutral-border: '#e2e2e2'
  ghost-cyan: rgba(42, 199, 251, 0.1)
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 80px
    fontWeight: '800'
    lineHeight: 88px
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.04em
  headline-md:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
spacing:
  unit: 8px
  gutter: 24px
  margin-sm: 16px
  margin-md: 40px
  margin-lg: 80px
  stack-offset: 2px
---

## Brand & Style

This design system evolves the original "Kinetic Blueprint" aesthetic into a high-clarity, light-mode environment. It retains the **Schematic Minimalism** and technical precision of aerospace engineering but shifts from a "HUD in the dark" feel to a "Clinical Laboratory" or "Architectural Drafting" vibe. 

The visual narrative is driven by **Technical Sophistication**. It uses a stark white canvas to emphasize structural linework, fine typography, and high-energy accents. The style remains a hybrid of **Corporate Modern** and **Technological Brutalism**, but the "Industrial" aspect is polished, professional, and optimized for maximum legibility.

Key visual pillars:
- **Clarity:** Pure white surfaces with razor-sharp black and cyan accents.
- **Structural Integrity:** Visible grid logic and mathematical alignment.
- **Modern Professionalism:** A clean, airy feel that doesn't sacrifice the technical "nerd-factor" of the original system.

## Colors

The palette is anchored by a pure **Primary Surface** of `#FFFFFF`. To maintain the architectural aesthetic, we utilize **Deep Tech Black** (`#0e0e0e`) for primary text and structural borders, ensuring high-contrast legibility.

**Blueprint Cyan** (`#2ac7fb`) transitions from a glow effect to a structural accent color. It is used for active states, interactive borders, and technical "circuit" decorations. **Accent Yellow** is retained as a tertiary highlight, used sparingly for secondary offsets or "warning" states.

When layering, use a "Dark-on-Light Stack":
1. **Base:** White Surface.
2. **Stroke:** 1px Black or Cyan lines.
3. **Accent:** Yellow used as an offset "shadow" or sub-layer to create depth without using traditional gradients.

## Typography

Typography functions as the "schematic" labels of the design. **Sora** provides the heavy, geometric weight needed for high-impact headlines. On the white background, these should be rendered in **Deep Tech Black** to anchor the page.

**Hanken Grotesk** handles the body content with contemporary crispness, while **JetBrains Mono** is used for all technical meta-data, labels, and small-scale details.

The "Triple-Stack" typographic effect is adapted for light mode:
1. **Top layer:** Deep Tech Black text.
2. **Middle layer:** Blueprint Cyan, offset by 2px.
3. **Base layer:** Accent Yellow, offset by 4px.
This creates a vibrant, pop-art technical feel that remains legible.

## Layout & Spacing

This design system uses a **Fixed Grid** model to simulate the precision of a blueprint. The layout is strictly governed by an **8px base unit**, ensuring that every element—from the size of a "node" to the padding of a card—is mathematically proportional.

**Grid Philosophy:**
- **Desktop (1024px+):** 12-column fixed grid, max-width 1440px, 24px gutters.
- **Tablet (768px - 1024px):** 8-column grid, 32px margins.
- **Mobile (up to 768px):** 4-column grid, 16px margins.

To maintain the "Blueprint" aesthetic, use thin 1px horizontal and vertical "datum lines" that extend across the grid to separate major sections. These lines should use the `neutral-border` (`#e2e2e2`) to remain subtle but structural.

## Elevation & Depth

In light mode, depth is achieved through **Hard Offsets** and **Fine Outlines** rather than shadows. 

1. **Z-0 (The Drafting Board):** The white `#FFFFFF` surface.
2. **Z-1 (Plates):** White surfaces defined by a 1px `Deep Tech Black` or `Blueprint Cyan` border. 
3. **Z-2 (Active States):** Elements are elevated using a **Hard Shadow** technique—a solid block of color (usually Cyan or Yellow) offset by 4px or 8px behind the primary element.
4. **Transparency:** Use `ghost-cyan` for background fills on secondary buttons or inactive chips to provide a hint of tech-color without overwhelming the white space.

## Shapes

The shape language is **Sharp (0px)**. Roundness is avoided to maintain the architectural/blueprint theme.

**Stylistic Modifiers:**
- **Chamfers:** Use 45-degree corner cuts on buttons and container headers to reinforce the "engineered" look.
- **Terminals:** Any line or border that "ends" within the UI should be capped with a 4px x 4px solid black or cyan square (a "node").
- **Grid Nodes:** Use small `+` symbols at the intersections of major grid lines to mimic technical drawing software.

## Components

### Buttons
Buttons are strictly rectangular.
- **Primary:** Deep Tech Black background with White text. On hover, apply a 4px offset in Blueprint Cyan.
- **Secondary:** White background with a 1px Deep Tech Black border.
- **Technical Action:** Blueprint Cyan background with Deep Tech Black text. Use for primary call-to-actions.

### Cards & Plates
Cards are defined by 1px borders. Use "Corner Brackets"—small L-shaped lines at the four corners—in Blueprint Cyan. The header of a card should be separated by a 1px horizontal line with a small "Serial Number" in `label-sm` monospace font in the top-right corner.

### Input Fields
Inputs use a "Field Box" style: a 1px black border on the bottom and right sides only, creating an "open" but defined space. The label sits in `label-caps` directly above the field.

### Status Indicators
Use the "Triple-Dot" node pattern (three 4px squares in a row) to indicate status:
- **Active:** Cyan-Black-Black
- **Warning:** Yellow-Black-Black
- **Locked:** Black-Black-Black

### Data Grids
Tables and lists should use alternating row fills of `ghost-cyan` at 5% opacity to maintain row tracking without heavy borders. Use `JetBrains Mono` for all numeric data.