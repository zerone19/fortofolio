---
name: Arona Terminal
colors:
  surface: '#101419'
  surface-dim: '#101419'
  surface-bright: '#363940'
  surface-container-lowest: '#0b0e14'
  surface-container-low: '#181c22'
  surface-container: '#1c2026'
  surface-container-high: '#262a31'
  surface-container-highest: '#31353c'
  on-surface: '#e0e2eb'
  on-surface-variant: '#bcc8d1'
  inverse-surface: '#e0e2eb'
  inverse-on-surface: '#2d3137'
  outline: '#86929a'
  outline-variant: '#3d484f'
  surface-tint: '#75d1ff'
  primary: '#92d9ff'
  on-primary: '#003548'
  primary-container: '#00c2ff'
  on-primary-container: '#004c66'
  inverse-primary: '#006688'
  secondary: '#fff3d2'
  on-secondary: '#3a3000'
  secondary-container: '#fdd400'
  on-secondary-container: '#6f5c00'
  tertiary: '#c3d1e7'
  on-tertiary: '#233142'
  tertiary-container: '#a7b6cb'
  on-tertiary-container: '#394759'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c2e8ff'
  primary-fixed-dim: '#75d1ff'
  on-primary-fixed: '#001e2b'
  on-primary-fixed-variant: '#004d67'
  secondary-fixed: '#ffe170'
  secondary-fixed-dim: '#e9c400'
  on-secondary-fixed: '#221b00'
  on-secondary-fixed-variant: '#544600'
  tertiary-fixed: '#d5e4fa'
  tertiary-fixed-dim: '#b9c8dd'
  on-tertiary-fixed: '#0e1c2d'
  on-tertiary-fixed-variant: '#3a485a'
  background: '#101419'
  on-background: '#e0e2eb'
  surface-variant: '#31353c'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  unit-1: 4px
  unit-2: 8px
  unit-4: 16px
  unit-6: 24px
  unit-8: 32px
  unit-12: 48px
  container-margin: 24px
  gutter: 16px
---

## Brand & Style

The design system is an advanced, high-tech interface that prioritizes technical precision and cinematic data visualization. It is designed for high-performance admin environments where speed and clarity are paramount, but aesthetic immersion is equally valued.

The visual style is a fusion of **Corporate Modern** and **Cyber-Tech**. It utilizes a deep, multi-layered dark mode inspired by deep-space command centers. The personality is "Calculated, Elite, and Radiant." The core aesthetic relies on "Electric Circuitry"—utilizing thin, high-contrast lines and glowing accents that mimic the flow of data.

Key stylistic markers:
- **Glassmorphism:** Surfaces use high-density background blurs to create a sense of deep layered glass.
- **Cyber-accents:** Intentional use of "data-path" lines (1px strokes) and micro-terminal decorative elements.
- **High-Tech Glow:** Interactive elements emit a soft, localized aura, signaling system activity.

## Colors

The palette is anchored in **Deep Space (Neutral)** and **Circuit Blue (Primary)**.

- **Primary (#00C2FF):** Representing the "Arona" core. Used for active states, data paths, and critical interactive components. This color should always be paired with a subtle glow (outer shadow) when used on buttons or icons.
- **Secondary (#FFD600):** Used sparingly as a "Warning" or "Highlight" color. It provides a warm contrast to the cool blue tones, intended for high-priority alerts or distinctive data points.
- **Surface Tiers:**
    - **Background:** Solid black (#020408) for maximum contrast.
    - **Surface L1:** Deep Navy (#0A1929) at 60% opacity with a 20px backdrop blur.
    - **Surface L2:** A slightly lighter tint for nested containers.
- **Success/Error:** Use a vibrant emerald for success and a high-saturated crimson for errors, maintaining the "cyber" neon intensity.

## Typography

The typography system uses a tri-font hierarchy to balance personality and utility:

1.  **Hanken Grotesk (Headlines):** Sharp, contemporary, and authoritative. Used for major dashboard titles and section headers.
2.  **Geist (Body):** A highly legible, developer-focused sans-serif that excels in dark mode environments. Used for all primary content and descriptions.
3.  **JetBrains Mono (Labels/Data):** Employed for technical metadata, ID numbers, and small labels to reinforce the "Terminal" aesthetic.

**Scaling for Mobile:**
- `display-lg` scales down to `32px` on mobile.
- `headline-lg` scales down to `24px`.
- All `label` styles remain fixed to ensure legibility of technical data.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid Grid** system. 

- **Sidebar:** Fixed at 280px. It houses the primary navigation and "System Status" indicators.
- **Main Canvas:** A fluid 12-column grid that expands to fill the remaining viewport. 
- **Rhythm:** A 4px baseline grid is used. All component heights and margins must be multiples of 4.
- **Gutters:** Standardized at 16px to keep data-heavy views compact yet breathable.
- **Safe Zones:** High-level dashboard views should maintain a 32px padding from the top and right edges to allow the "glowing" UI elements space to breathe.

## Elevation & Depth

This design system rejects traditional shadows in favor of **Tonal Luminance and Backdrop Blurs**.

- **Z-Index 0 (Floor):** Pure black (#020408). No light.
- **Z-Index 1 (Base Cards):** Navy tint (#0A1929) with 40% opacity. 1px stroke of #ffffff10.
- **Z-Index 2 (Modals/Popovers):** Navy tint (#0A1929) with 80% opacity. 40px Backdrop Blur.
- **The "Circuit" Stroke:** Instead of a drop shadow, use an "Inner Glow" or a vibrant 1px border of Primary Blue (#00C2FF) to indicate focus or elevation.
- **Global Glow:** Components on Z-Index 2 should have a very soft, large-radius outer glow of #00C2FF (opacity 10%) to simulate light emission onto the floor.

## Shapes

The shape language is **Technical-Soft**. We use a base radius of 4px (Soft) for most components to maintain a professional, precision-engineered look. 

- **Containers:** 4px (Soft) for standard cards.
- **Interactive Elements:** 8px (rounded-lg) for buttons and inputs to make them more "touch-friendly" and distinct from layout containers.
- **Decorative Elements:** Use 45-degree clipped corners (chamfers) on specialized "Status Tags" or "System Overlays" to mimic military hardware interfaces.

## Components

### Buttons
- **Primary:** Solid Primary Blue background, JetBrains Mono font (bold), white text. Add a `box-shadow: 0 0 15px rgba(0, 194, 255, 0.4)` on hover.
- **Ghost:** Transparent background, 1px Primary Blue border. Blue text.

### Input Fields
- **Design:** Dark background (#050C14), 1px border (#ffffff20). On focus, the border turns Primary Blue with a subtle "pulse" animation.
- **Typography:** Use Geist for user input and JetBrains Mono for the field label.

### Cards & Glass Containers
- **Style:** Semi-transparent Navy (#0A1929 at 60%), 20px blur. 
- **Detail:** Add a 1px "Circuit Trace" (a line that only covers 20% of the top and left border) in Primary Blue to create a technical ornament.

### Chips & Status Indicators
- **Style:** Small, pill-shaped or chamfered rectangles.
- **Colors:** Use "Glow" variants of the palette (e.g., a faint yellow background with a bright yellow dot for "Warning").

### Data Visualization
- **Line Charts:** Use Primary Blue for the main data line with a gradient area fill below it (Blue to Transparent).
- **Grid Lines:** Use very faint dashed lines (#ffffff05).

### Navigation (Sidebar)
- **Active State:** A vertical glow bar on the left edge of the menu item. The icon and text transition from gray to Primary Blue.