---
name: Arona Light Terminal
colors:
  surface: '#f7f9fe'
  surface-dim: '#d7dade'
  surface-bright: '#f7f9fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f8'
  surface-container: '#ebeef2'
  surface-container-high: '#e6e8ec'
  surface-container-highest: '#e0e3e7'
  on-surface: '#181c1f'
  on-surface-variant: '#3f484e'
  inverse-surface: '#2d3134'
  inverse-on-surface: '#eef1f5'
  outline: '#6f787f'
  outline-variant: '#bfc8cf'
  surface-tint: '#F0F7FF'
  primary: '#005c80'
  on-primary: '#ffffff'
  primary-container: '#0076a3'
  on-primary-container: '#e6f4ff'
  inverse-primary: '#81cfff'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed65b'
  on-secondary-container: '#745c00'
  tertiary: '#7d4a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#9d600a'
  on-tertiary-container: '#ffefe2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c6e7ff'
  primary-fixed-dim: '#81cfff'
  on-primary-fixed: '#001e2d'
  on-primary-fixed-variant: '#004c6b'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#ffdcbc'
  tertiary-fixed-dim: '#ffb86a'
  on-tertiary-fixed: '#2c1700'
  on-tertiary-fixed-variant: '#683d00'
  background: '#f7f9fe'
  on-background: '#181c1f'
  surface-variant: '#e0e3e7'
  surface-border: '#E2E8F0'
  text-primary: '#0F172A'
  text-secondary: '#475569'
  accent-blue-bright: '#00C2FF'
  accent-yellow-gold: '#FDD400'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.1em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.2'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-sm: 16px
  margin-md: 24px
  margin-lg: 32px
  sidebar-width: 260px
---

## Brand & Style

This design system reimagines the "Arona Terminal" aesthetic for a high-clarity, professional environment. It transitions from a dark "command center" vibe to a **Clean Modern / Cyber-Tech** light theme. The personality is "Precision, Analytical, and Sophisticated."

The visual style leverages **Minimalism** with subtle **Glassmorphism** to maintain the technical depth of the original brand. It replaces the deep-space atmosphere with a pure, high-contrast workspace that mimics advanced laboratory instrumentation or premium fintech platforms.

Key stylistic markers:
- **Pristine Surfaces:** Utilizing pure white (#FFFFFF) and subtle blue-tinted whites to create a sense of clinical precision.
- **Micro-Technical Accents:** Maintaining the "cyber" heritage through 1px hairline strokes, monospaced data labels, and technical "crosshair" ornaments, but executed in dark grays rather than neon glows.
- **Tactile Precision:** Interactive elements use crisp edges and subtle elevation rather than heavy shadows, emphasizing a "tool-like" utility.

## Colors

The palette is optimized for high-contrast readability on a light background while retaining the signature blue and yellow brand accents.

- **Primary (#0076A3):** A deepened version of the brand blue, adjusted for AAA accessibility on white. Used for primary actions and active states.
- **Secondary (#D4AF37):** A sophisticated gold-tinted yellow. Used for critical alerts, highlights, and secondary technical indicators.
- **Surface Tiers:**
    - **Background:** Pure White (#FFFFFF) for maximum clarity.
    - **Surface L1:** Subtle blue-tinted white (#F8FAFC) used for sidebars and secondary containers.
    - **Surface L2:** A light gray-blue (#F1F5F9) for nested elements or inactive states.
- **Typography:** Headlines and primary body text use "Midnight Slate" (#0F172A) to ensure sharp focus, while metadata uses "Cool Gray" (#64748B).

## Typography

The typography maintains a professional tri-font system, prioritizing legibility and a "system-interface" feel.

- **Hanken Grotesk (Headlines):** High-impact and authoritative. Used for titles. In light mode, the heavier weights provide the necessary visual anchor against the white background.
- **Geist (Body):** A modern sans-serif that remains highly readable at all sizes. Used for the bulk of content.
- **JetBrains Mono (Technical):** Essential for maintaining the "Terminal" identity. Used for data points, ID tags, and navigation labels.

**Color Usage:** Use the darkest slate for all headlines. Body text should be slightly softened to dark gray to reduce eye strain over long periods of use.

## Layout & Spacing

The layout uses a **Fixed Grid** system for the primary interface structure to ensure a disciplined, technical appearance.

- **Grid:** A 12-column grid is standard for content areas.
- **Sidebar:** A fixed-width (260px) navigation panel on the left, utilizing a subtle blue-tinted surface (#F8FAFC) to separate it from the main canvas.
- **Rhythm:** An 8px base unit controls all spacing. Small components (chips/icons) may use a 4px increment for tighter density.
- **Responsive Behavior:** 
    - **Desktop:** Full sidebar and 32px external margins.
    - **Tablet:** Sidebar collapses into an icon-only rail or hamburger menu; margins reduce to 24px.
    - **Mobile:** Single column layout with 16px margins; typography scales down per the defined tokens.

## Elevation & Depth

In this light theme, depth is communicated through **Tonal Layering** and **Low-Contrast Outlines** rather than heavy shadows.

- **Z-Index 0 (Base):** Pure White (#FFFFFF).
- **Z-Index 1 (Cards):** Surface L1 tint with a 1px border (#E2E8F0).
- **Z-Index 2 (Overlays/Modals):** Pure White with a 1px border and a very soft, diffused ambient shadow (Color: #0F172A at 4% opacity, 16px blur).
- **Glassmorphism:** For top-level navigation bars or floating tooltips, use a white background at 80% opacity with a 12px backdrop blur to maintain the high-tech terminal aesthetic.
- **Technical Detail:** Instead of drop shadows, use "Ghost Borders"—a 1px inset border in a light blue shade—to give components a "machined" feel.

## Shapes

The shape language is **Soft-Technical**. We use a disciplined 4px radius (Soft) to keep the interface looking sharp and professional, avoiding the playfulness of larger rounds.

- **Small (0.25rem):** Standard for inputs, buttons, and cards.
- **Large (0.5rem):** Used for primary dashboard containers or modal windows.
- **Chamfers:** 45-degree clipped corners may be used on small decorative labels or "System Status" tags to reinforce the cyber-tech heritage without cluttering the light theme.

## Components

### Buttons
- **Primary:** Solid Primary Blue (#0076A3) with white text. No glow. Use a 1px darker bottom border for a subtle "pressed" effect on click.
- **Secondary:** White background with a 1px border of #0076A3. Blue text.
- **Action Label:** Always use JetBrains Mono for button labels to maintain the technical feel.

### Input Fields
- **Design:** White background with a 1px border (#CBD5E1). 
- **Focus:** Border changes to Primary Blue with a 2px "outer-stroke" of the primary color at 20% opacity.

### Cards
- **Style:** Flat white background. Instead of a shadow, use a 1px border (#E2E8F0).
- **Header:** A subtle horizontal line (1px) separating the card header from the body, using the secondary yellow as a 2px "accent tab" in the top-left corner.

### List Items
- **Style:** Clean, 1px bottom border (#F1F5F9). On hover, the entire row transitions to the Surface L1 tint.
- **Data Columns:** Ensure all numerical data is set in JetBrains Mono for perfect vertical alignment.

### Checkboxes & Radios
- **Design:** Square with a 2px radius. Use Primary Blue for the checked state.

### Chips & Tags
- **Style:** Rectangular with a 2px radius. Light blue background with dark blue text for "Info," and light yellow with dark gold text for "Warnings." Use Geist SemiBold for chip text.